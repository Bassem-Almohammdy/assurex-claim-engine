from dataclasses import dataclass, asdict
from datetime import date

@dataclass
class RuleResult:
    code:str; severity:str; passed:bool; message:str; evidence:dict
    def as_dict(self): return asdict(self)

class RuleEngine:
    def evaluate(self, claim, policy):
        results=[]
        def add(code,severity,passed,message,**evidence): results.append(RuleResult(code,severity,passed,message,evidence))
        sd=claim["submission_date"]; fd=claim["fault_date"]; pd=claim["purchase_date"]; exp=claim["warranty_expiry"]
        add("WARRANTY_ACTIVE","PASS" if sd<=exp else "HARD_FAIL",sd<=exp,"Warranty is active." if sd<=exp else "Warranty expired.",submission_date=str(sd),expiry=str(exp))
        add("FAULT_BEFORE_PURCHASE","MANUAL_REVIEW",fd>=pd,"Fault date is after purchase date." if fd>=pd else "Fault predates purchase.",fault_date=str(fd),purchase_date=str(pd))
        add("FAULT_AFTER_SUBMISSION","MANUAL_REVIEW",fd<=sd,"Fault date is not after submission." if fd<=sd else "Fault occurs after submission.")
        excluded=set(policy.get("exclusions",[])); damage=claim.get("damage_type")
        add("EXCLUDED_DAMAGE","HARD_FAIL",damage not in excluded,"Damage type is covered or unspecified." if damage not in excluded else "Damage type is explicitly excluded.",damage_type=damage)
        covered=set(policy.get("covered_faults",[])); fault=claim.get("fault_type")
        add("FAULT_COVERAGE","PASS" if fault in covered else "MANUAL_REVIEW",fault in covered,"Fault is covered." if fault in covered else "Fault is not listed as covered.",fault_type=fault)
        add("SERIAL_NUMBER_MATCH","PASS" if claim.get("serial_match") else "MANUAL_REVIEW",bool(claim.get("serial_match")),"Serial number matches evidence." if claim.get("serial_match") else "Serial number mismatch or not verified.")
        mandatory=set(policy.get("mandatory_documents",[])); docs=set(claim.get("documents",[])); missing=sorted(mandatory-docs)
        add("MANDATORY_DOCUMENTS","PASS" if not missing else "MANUAL_REVIEW",not missing,"All mandatory documents are present." if not missing else "Mandatory documents are missing.",missing=missing)
        repairs=claim.get("repairs",[])
        unauthorized=any(not r.get("authorized_center",False) for r in repairs)
        sev="MANUAL_REVIEW" if policy.get("authorized_service_center_required",False) and unauthorized else "PASS"
        add("REPAIR_AUTHORIZATION",sev,not unauthorized,"Repair history satisfies authorization policy." if not unauthorized else "Unauthorized repair detected.")
        add("DUPLICATE_CHECK","MANUAL_REVIEW",not claim.get("duplicate_claim",False),"No duplicate indicator." if not claim.get("duplicate_claim",False) else "Possible duplicate claim detected.")
        add("CONTRADICTION_CHECK","MANUAL_REVIEW",not claim.get("contradictions"),"No contradictions detected." if not claim.get("contradictions") else "Conflicting claim information detected.")
        return results

    def summary(self, results):
        hard=[r.code for r in results if r.severity=="HARD_FAIL" and not r.passed]
        manual=[r.code for r in results if r.severity=="MANUAL_REVIEW" and not r.passed]
        return {"passed":sum(r.passed for r in results),"failed":sum(not r.passed for r in results),"hard_fail_rules":hard,"manual_review_rules":manual,"requires_manual_review":bool(manual),"hard_fail_count":len(hard)}
