from datetime import date, datetime
from enum import Enum
from sqlalchemy import String, Integer, Float, Boolean, Date, DateTime, ForeignKey, JSON, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.session import Base

class UserRole(str, Enum):
    CUSTOMER="Customer"; SERVICE_CENTER="Service Center"; REVIEWER="Reviewer"; ADMIN="Admin"
class ClaimStatus(str, Enum):
    DRAFT="Draft"; SUBMITTED="Submitted"; UNDER_EVALUATION="Under Evaluation"; ADDITIONAL_INFO="Additional Information Required"; MANUAL_REVIEW="Manual Review"; APPROVED="Approved"; REJECTED="Rejected"; CLOSED="Closed"
class Decision(str, Enum):
    LIKELY_VALID="Likely Valid"; LIKELY_INVALID="Likely Invalid"; MANUAL_REVIEW="Manual Review Required"

class User(Base):
    __tablename__="users"
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(150))
    email: Mapped[str]=mapped_column(String(255),unique=True,index=True)
    password_hash: Mapped[str]=mapped_column(String(255))
    role: Mapped[UserRole]=mapped_column(default=UserRole.CUSTOMER)
    is_active: Mapped[bool]=mapped_column(Boolean,default=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    products: Mapped[list["Product"]]=relationship(back_populates="owner")
    claims: Mapped[list["Claim"]]=relationship(back_populates="claimant")

class Product(Base):
    __tablename__="products"
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey("users.id"),index=True)
    product_name: Mapped[str]=mapped_column(String(150)); category: Mapped[str]=mapped_column(String(80),index=True)
    brand: Mapped[str]=mapped_column(String(100)); model_number: Mapped[str]=mapped_column(String(120)); serial_number: Mapped[str]=mapped_column(String(120),index=True)
    purchase_date: Mapped[date]=mapped_column(Date); purchase_price: Mapped[float|None]=mapped_column(Float); retailer: Mapped[str|None]=mapped_column(String(150))
    owner: Mapped[User]=relationship(back_populates="products"); warranties: Mapped[list["Warranty"]]=relationship(back_populates="product"); claims: Mapped[list["Claim"]]=relationship(back_populates="product")

class Warranty(Base):
    __tablename__="warranties"
    id: Mapped[int]=mapped_column(primary_key=True); product_id: Mapped[int]=mapped_column(ForeignKey("products.id"),index=True)
    provider: Mapped[str]=mapped_column(String(150)); start_date: Mapped[date]=mapped_column(Date); expiry_date: Mapped[date]=mapped_column(Date,index=True)
    duration_days: Mapped[int]; is_extended: Mapped[bool]=mapped_column(Boolean,default=False); service_center: Mapped[str|None]=mapped_column(String(150))
    policy_category: Mapped[str]=mapped_column(String(80),index=True); policy_version: Mapped[str]=mapped_column(String(50))
    product: Mapped[Product]=relationship(back_populates="warranties"); claims: Mapped[list["Claim"]]=relationship(back_populates="warranty")

class Claim(Base):
    __tablename__="claims"
    id: Mapped[int]=mapped_column(primary_key=True); claim_number: Mapped[str]=mapped_column(String(40),unique=True,index=True)
    user_id: Mapped[int]=mapped_column(ForeignKey("users.id"),index=True); product_id: Mapped[int]=mapped_column(ForeignKey("products.id"),index=True); warranty_id: Mapped[int]=mapped_column(ForeignKey("warranties.id"),index=True)
    fault_date: Mapped[date]; submission_date: Mapped[date]; fault_description: Mapped[str]=mapped_column(Text); fault_type: Mapped[str|None]=mapped_column(String(100)); damage_type: Mapped[str|None]=mapped_column(String(100));
    status: Mapped[ClaimStatus]=mapped_column(default=ClaimStatus.DRAFT,index=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); updated_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
    claimant: Mapped[User]=relationship(back_populates="claims"); product: Mapped[Product]=relationship(back_populates="claims"); warranty: Mapped[Warranty]=relationship(back_populates="claims")
    documents: Mapped[list["ClaimDocument"]]=relationship(back_populates="claim",cascade="all, delete-orphan"); repairs: Mapped[list["Repair"]]=relationship(back_populates="claim",cascade="all, delete-orphan"); predictions: Mapped[list["Prediction"]]=relationship(back_populates="claim",cascade="all, delete-orphan"); rule_results: Mapped[list["RuleResult"]]=relationship(back_populates="claim",cascade="all, delete-orphan"); decisions: Mapped[list["ClaimDecision"]]=relationship(back_populates="claim",cascade="all, delete-orphan")

class ClaimDocument(Base):
    __tablename__="claim_documents"
    id: Mapped[int]=mapped_column(primary_key=True); claim_id: Mapped[int]=mapped_column(ForeignKey("claims.id"),index=True)
    document_type: Mapped[str]=mapped_column(String(80)); file_name: Mapped[str]=mapped_column(String(255)); file_path: Mapped[str]=mapped_column(String(500)); file_hash: Mapped[str]=mapped_column(String(64),index=True)
    mime_type: Mapped[str|None]=mapped_column(String(100)); ocr_status: Mapped[str]=mapped_column(String(50),default="pending"); verification_status: Mapped[str]=mapped_column(String(50),default="pending"); extracted_data: Mapped[dict|None]=mapped_column(JSON)
    uploaded_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); claim: Mapped[Claim]=relationship(back_populates="documents")

class Repair(Base):
    __tablename__="repairs"
    id: Mapped[int]=mapped_column(primary_key=True); claim_id: Mapped[int|None]=mapped_column(ForeignKey("claims.id")); product_id: Mapped[int]=mapped_column(ForeignKey("products.id"),index=True)
    repair_date: Mapped[date]; repair_center: Mapped[str]; replaced_parts: Mapped[str|None]=mapped_column(Text); repair_outcome: Mapped[str|None]=mapped_column(Text); repair_cost: Mapped[float|None]=mapped_column(Float); authorized_center: Mapped[bool]=mapped_column(Boolean,default=False)
    claim: Mapped[Claim|None]=relationship(back_populates="repairs")

class Prediction(Base):
    __tablename__="predictions"
    id: Mapped[int]=mapped_column(primary_key=True); claim_id: Mapped[int]=mapped_column(ForeignKey("claims.id"),index=True); model_type: Mapped[str]=mapped_column(String(40)); model_version: Mapped[str]; predicted_class: Mapped[str]; confidence: Mapped[float]; probabilities: Mapped[dict]=mapped_column(JSON); created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    claim: Mapped[Claim]=relationship(back_populates="predictions")

class RuleResult(Base):
    __tablename__="rule_results"
    id: Mapped[int]=mapped_column(primary_key=True); claim_id: Mapped[int]=mapped_column(ForeignKey("claims.id"),index=True); rule_code: Mapped[str]; severity: Mapped[str]; passed: Mapped[bool]; message: Mapped[str]; evidence: Mapped[dict]=mapped_column(JSON,default=dict); created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    claim: Mapped[Claim]=relationship(back_populates="rule_results")

class ClaimDecision(Base):
    __tablename__="claim_decisions"
    id: Mapped[int]=mapped_column(primary_key=True); claim_id: Mapped[int]=mapped_column(ForeignKey("claims.id"),index=True); decision: Mapped[Decision]; explanation: Mapped[dict]=mapped_column(JSON); policy_version: Mapped[str]; created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    claim: Mapped[Claim]=relationship(back_populates="decisions")

class ManualReview(Base):
    __tablename__="manual_reviews"
    id: Mapped[int]=mapped_column(primary_key=True); claim_id: Mapped[int]=mapped_column(ForeignKey("claims.id"),index=True); reason: Mapped[str]; priority: Mapped[str]=mapped_column(String(30),default="normal"); status: Mapped[str]=mapped_column(String(30),default="pending"); reviewer_comment: Mapped[str|None]=mapped_column(Text); override_decision: Mapped[str|None]=mapped_column(String(50)); created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); resolved_at: Mapped[datetime|None]=mapped_column(DateTime)

class AuditLog(Base):
    __tablename__="audit_logs"
    id: Mapped[int]=mapped_column(primary_key=True); user_id: Mapped[int|None]=mapped_column(ForeignKey("users.id")); action: Mapped[str]; entity_type: Mapped[str]; entity_id: Mapped[str]; old_value: Mapped[dict|None]=mapped_column(JSON); new_value: Mapped[dict|None]=mapped_column(JSON); created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
