from fastapi import FastAPI
from app.db.session import Base,engine
from app.models import entities
from app.api.routes import router

Base.metadata.create_all(bind=engine)
app=FastAPI(title="AssureX Claim Engine Backend",version="1.0.0",description="Backend, database, warranty rules and model-decision orchestration for AssureX.")
app.include_router(router)
@app.get("/health")
def root_health(): return {"status":"ok","service":"AssureX Claim Engine"}
