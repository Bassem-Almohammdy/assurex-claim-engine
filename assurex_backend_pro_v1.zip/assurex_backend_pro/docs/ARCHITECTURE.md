# AssureX Backend Architecture

Frontend -> FastAPI routes -> services -> database
                              |-> Rule Engine -> policy JSON
                              |-> Python model adapter
                              |-> Teachable Machine adapter
                              `-> Decision Engine -> Manual Review queue

## TM contract
Legal labels: `Valid`, `Invalid`, `Manual Review`.
Legacy labels are accepted only at the integration boundary and immediately normalized.
TM confidence is the top-class probability. Confidence difference is `abs(python_confidence - tm_confidence)`.

## Why an adapter
Member 3's uploaded predictor currently exposes the older function contract. The adapter prevents the rest of the backend from depending on that implementation detail.
