from datetime import date
from pydantic import BaseModel, Field

class ClaimCreate(BaseModel):
    user_id:int; product_id:int; warranty_id:int; fault_date:date; submission_date:date; fault_description:str=Field(min_length=3); fault_type:str|None=None; damage_type:str|None=None

class EvaluateResponse(BaseModel):
    claim_id:int; claim_number:str; decision:str; status:str; rule_summary:dict; model_comparison:dict|None; explanation:dict
