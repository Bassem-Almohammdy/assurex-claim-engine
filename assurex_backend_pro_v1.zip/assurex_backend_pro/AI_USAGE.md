# AI Usage Declaration

Tool: ChatGPT
Purpose: Architecture assistance, code scaffolding, explanation, testing ideas, and integration planning.
Modules affected: Backend, database, rule engine, model adapter.
Team responsibility: Review, modify, test, and understand every generated module before submission.

This declaration is required by the SRS. The team must record the actual prompts/assistance used and the team member who verified each affected module.
