def compare_models(py_prediction,py_confidence,tm_prediction,tm_confidence,min_confidence=0.60,strong_diff=0.10,acceptable_diff=0.20):
    diff=abs(py_confidence-tm_confidence)
    if py_confidence<min_confidence or tm_confidence<min_confidence: status="Uncertain Result"
    elif py_prediction!=tm_prediction: status="Model Disagreement"
    elif diff<=strong_diff: status="Strong Match"
    elif diff<=acceptable_diff: status="Acceptable Match"
    else: status="Weak Match"
    return {"prediction_match":py_prediction==tm_prediction,"confidence_difference":diff,"status":status}

def final_decision(rule_summary, comparison, python_prediction=None, tm_prediction=None):
    if rule_summary["hard_fail_count"]: return "Likely Invalid"
    if rule_summary["requires_manual_review"]: return "Manual Review Required"
    if comparison and comparison["status"] in {"Model Disagreement","Uncertain Result","Weak Match"}: return "Manual Review Required"
    if python_prediction=="Valid" and tm_prediction=="Valid": return "Likely Valid"
    if python_prediction=="Invalid" and tm_prediction=="Invalid": return "Likely Invalid"
    return "Manual Review Required"
