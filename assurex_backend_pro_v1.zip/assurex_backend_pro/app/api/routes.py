from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
import json, shutil, uuid
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Claim, ClaimStatus
from app.schemas.claim import ClaimCreate
from app.services.evaluation import ClaimEvaluator
from app.integrations.tm_adapter import TMAdapter
from app.core.config import settings

router=APIRouter(prefix="/api/v1",tags=["claims"])

def tm():
    return TMAdapter(settings.tm_model_dir)

@router.get("/health")
def health(): return {"status":"ok","service":"assurex-backend","api":"v1"}

@router.post("/claims")
def create_claim(data:ClaimCreate,db:Session=Depends(get_db)):
    claim=Claim(claim_number=f"AX-{data.user_id}-{data.product_id}-{data.submission_date.strftime('%Y%m%d')}-{abs(hash((data.user_id,data.product_id,data.submission_date.isoformat())))%100000:05d}",**data.model_dump(),status=ClaimStatus.SUBMITTED)
    db.add(claim); db.commit(); db.refresh(claim); return {"id":claim.id,"claim_number":claim.claim_number,"status":claim.status}

@router.get("/claims/{claim_id}")
def get_claim(claim_id:int,db:Session=Depends(get_db)):
    c=db.get(Claim,claim_id)
    if not c: raise HTTPException(404,"Claim not found")
    return {"id":c.id,"claim_number":c.claim_number,"status":c.status,"product_id":c.product_id,"warranty_id":c.warranty_id}


@router.post("/claims/{claim_id}/evaluate")
def evaluate_claim(claim_id:int, python_prediction:str=Form(...), python_confidence:float=Form(...), python_probabilities:str=Form("{}"), python_model_version:str=Form("unknown"), card:UploadFile|None=File(None), db:Session=Depends(get_db)):
    claim=db.get(Claim,claim_id)
    if not claim: raise HTTPException(404,"Claim not found")
    try: probs=json.loads(python_probabilities)
    except json.JSONDecodeError: raise HTTPException(400,"python_probabilities must be valid JSON")
    image_path=None
    if card:
        if card.content_type not in {"image/jpeg","image/png","image/jpg"}: raise HTTPException(400,"Claim Summary Card must be JPG or PNG")
        from pathlib import Path
        upload_dir=Path(settings.upload_dir); upload_dir.mkdir(parents=True,exist_ok=True)
        image_path=upload_dir/f"{uuid.uuid4().hex}_{card.filename}"
        with image_path.open("wb") as f: shutil.copyfileobj(card.file,f)
    result=ClaimEvaluator(db,tm_adapter=tm()).evaluate(claim,{"prediction":python_prediction,"confidence":python_confidence,"probabilities":probs,"model_version":python_model_version},image_path)
    return {"claim_id":claim.id,"claim_number":claim.claim_number,"status":claim.status,"decision":result["decision"],"rule_summary":result["rule_summary"],"model_comparison":result["model_comparison"],"tm_result":result["tm_result"],"explanation":result["explanation"]}
