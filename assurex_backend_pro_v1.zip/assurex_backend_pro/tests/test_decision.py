from app.services.decision import compare_models,final_decision

def test_tm_legal_labels():
    x=compare_models("Valid",.88,"Valid",.84); assert x["status"]=="Strong Match"

def test_disagreement_goes_manual():
    x=compare_models("Valid",.91,"Invalid",.92); assert x["status"]=="Model Disagreement"
    assert final_decision({"hard_fail_count":0,"requires_manual_review":False},x,"Valid","Invalid")=="Manual Review Required"

def test_hard_fail_invalid():
    assert final_decision({"hard_fail_count":1,"requires_manual_review":False},None,"Valid","Valid")=="Likely Invalid"
