from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./assurex.db"
    secret_key: str = "change-this-in-production"
    access_token_expire_minutes: int = 60
    tm_model_dir: str = "./model/tm_model"
    upload_dir: str = "./storage/uploads"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
