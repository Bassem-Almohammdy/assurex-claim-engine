import json
from pathlib import Path

class PolicyLoader:
    def __init__(self, directory="policies"): self.directory=Path(directory)
    def load(self, category):
        path=self.directory/f"{category.lower()}.json"
        if not path.exists(): raise FileNotFoundError(f"Warranty policy not found: {category}")
        return json.loads(path.read_text(encoding="utf-8"))
