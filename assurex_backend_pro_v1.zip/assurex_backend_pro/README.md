# AssureX Backend Pro

Backend foundation for AssureX: FastAPI + SQLAlchemy + configurable warranty policies + Rule Engine + Python/TM model orchestration.

## Key design
- Database is the source of truth for claims, documents, predictions, rule results, decisions and audit data.
- Warranty rules live in `policies/`, not scattered hard-coded logic.
- `app/integrations/tm_adapter.py` isolates Member 3's Teachable Machine implementation and normalizes both old and new labels to `Valid`, `Invalid`, `Manual Review`.
- The final decision is produced by application logic combining model comparison and warranty rules; no external generative AI API is used.

## Run
```bash
python -m venv .venv
# activate it
pip install -r requirements.txt
uvicorn app.main:app --reload
```
For TM integration:
```bash
pip install -r requirements-tm.txt
```
Put the teammate files under `model/tm_model/` and place `predict_tm.py` at project root, or pass the adapter a custom predictor path.

## Tests
```bash
pytest -q
```

## API
- `GET /health`
- `GET /api/v1/health`
- `POST /api/v1/claims`
- `GET /api/v1/claims/{claim_id}`

More routes should be added around the same service layer rather than putting business logic inside route handlers.
