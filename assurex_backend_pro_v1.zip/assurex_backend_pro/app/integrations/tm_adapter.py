import importlib.util
from pathlib import Path

LEGAL={"Valid":"Valid","Invalid":"Invalid","Manual Review":"Manual Review","Valid_Claim":"Valid","Invalid_Claim":"Invalid","Manual_Review":"Manual Review"}

class TMAdapter:
    def __init__(self, model_dir="model/tm_model", predictor_path=None):
        self.model_dir=Path(model_dir); self.predictor_path=Path(predictor_path) if predictor_path else self.model_dir.parent.parent/"predict_tm.py"; self._fn=None
    def _load(self):
        if self._fn: return
        if not self.predictor_path.exists(): raise FileNotFoundError(f"TM predictor not found: {self.predictor_path}")
        spec=importlib.util.spec_from_file_location("assurex_team_tm_predictor", self.predictor_path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); self._fn=mod.predict
    def predict(self, image, claim_id=None):
        self._load()
        try: raw=self._fn(image, model_dir=str(self.model_dir), claim_id=claim_id)
        except TypeError: raw=self._fn(str(image), model_dir=str(self.model_dir))
        pred=LEGAL.get(raw.get("tm_prediction"), raw.get("tm_prediction"))
        probs={LEGAL.get(k,k):float(v) for k,v in raw.get("tm_probabilities",{}).items()}
        return {"claim_id":claim_id,"tm_prediction":pred,"tm_probabilities":probs,"tm_confidence":float(raw.get("tm_confidence",0)),"tm_raw_label":raw.get("tm_prediction"),"model_version":raw.get("model_version","unknown")}
