from datetime import datetime
from app.models.entities import ClaimStatus, Prediction, RuleResult as DBRuleResult, ClaimDecision, ManualReview
from app.rules.loader import PolicyLoader
from app.rules.engine import RuleEngine
from app.services.decision import compare_models, final_decision

class ClaimEvaluator:
    def __init__(self, db, policy_dir="policies", tm_adapter=None): self.db=db; self.loader=PolicyLoader(policy_dir); self.rules=RuleEngine(); self.tm=tm_adapter
    def evaluate(self, claim, python_result=None, card_image=None):
        policy=self.loader.load(claim.warranty.policy_category)
        payload={"submission_date":claim.submission_date,"fault_date":claim.fault_date,"purchase_date":claim.product.purchase_date,"warranty_expiry":claim.warranty.expiry_date,"damage_type":claim.damage_type,"fault_type":claim.fault_type,"serial_match":True,"documents":[d.document_type for d in claim.documents],"repairs":[{"authorized_center":r.authorized_center} for r in claim.repairs],"duplicate_claim":False,"contradictions":False}
        rules=self.rules.evaluate(payload,policy); summary=self.rules.summary(rules)
        for r in rules: self.db.add(DBRuleResult(claim_id=claim.id,rule_code=r.code,severity=r.severity,passed=r.passed,message=r.message,evidence=r.evidence))
        tm_result=None; comparison=None
        if card_image and self.tm: tm_result=self.tm.predict(card_image,claim.id)
        if python_result and tm_result:
            comparison=compare_models(python_result["prediction"],python_result["confidence"],tm_result["tm_prediction"],tm_result["tm_confidence"])
        decision=final_decision(summary,comparison,python_result and python_result["prediction"],tm_result and tm_result["tm_prediction"])
        if python_result: self.db.add(Prediction(claim_id=claim.id,model_type="python",model_version=python_result.get("model_version","unknown"),predicted_class=python_result["prediction"],confidence=python_result["confidence"],probabilities=python_result.get("probabilities",{})))
        if tm_result: self.db.add(Prediction(claim_id=claim.id,model_type="teachable_machine",model_version=tm_result["model_version"],predicted_class=tm_result["tm_prediction"],confidence=tm_result["tm_confidence"],probabilities=tm_result["tm_probabilities"]))
        explanation={"supporting_rules":[r.code for r in rules if r.passed],"failed_rules":[r.code for r in rules if not r.passed],"model_comparison":comparison,"missing_documents":next((r.evidence.get("missing",[]) for r in rules if r.code=="MANDATORY_DOCUMENTS"),[])}
        self.db.add(ClaimDecision(claim_id=claim.id,decision=decision,explanation=explanation,policy_version=str(policy.get("version","unknown"))))
        if decision=="Manual Review Required": self.db.add(ManualReview(claim_id=claim.id,reason="; ".join(summary["manual_review_rules"])+("; model comparison" if comparison and comparison["status"]!="Strong Match" else "")))
        claim.status=ClaimStatus.MANUAL_REVIEW if decision=="Manual Review Required" else ClaimStatus.UNDER_EVALUATION
        self.db.commit()
        return {"decision":decision,"rule_summary":summary,"model_comparison":comparison,"tm_result":tm_result,"explanation":explanation}
